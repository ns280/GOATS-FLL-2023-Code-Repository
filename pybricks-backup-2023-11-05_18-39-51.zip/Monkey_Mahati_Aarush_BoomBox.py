from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase, GyroDriveBase
from pybricks.tools import wait, StopWatch
from pybricks.tools import hub_menu

hub = PrimeHub()

left_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.D)

drive_base = GyroDriveBase(left_motor, right_motor, wheel_diameter=62.5, axle_track=136)
drive_base.settings(300,600,100,200)


Right_arm = Motor(Port.E, Direction.COUNTERCLOCKWISE, [24, 12, 12, 24])
Left_arm = Motor(Port.A, Direction.COUNTERCLOCKWISE, [24, 12, 12, 24])

speed =600

#Code Starts here!
# THis part of the code works
#drive_base.turn(-6)
#drive_base.straight(725)
#drive_base.turn(45)
#drive_base.straight(160)
#Left_arm.run_target(600, -928.8)
# Code works end
#Aarush being the failure he is, cannot position it
#drive_base.turn(-6)
#drive_base.straight(680)
#drive_base.curve(150,40)
#drive_base.straight(125)
#Right_arm.run_target(400,170)
#Left_arm.run_target(600,-915)
#drive_base.straight(-100)
#Retry    3493840488820192 
drive_base.turn(-5) 
drive_base.straight(795)
Right_arm.run_angle(500,315)
drive_base.straight(-40)
Right_arm.run_target(500,-20)
drive_base.turn(45)
drive_base.straight(150)
Left_arm.run_target(600, -1000)
Right_arm.run_target(600,200)
drive_base.straight(-75)